import React from 'react';

interface HumanModelProps {
  className?: string;
  style?: React.CSSProperties;
}

const HumanModel: React.FC<HumanModelProps> = ({ className, style }) => {
  return (
    <svg
      viewBox="0 0 400 600"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={style}
    >
      <ellipse cx="200" cy="320" rx="70" ry="90" fill="#42A5F5"/>
      <rect x="185" y="240" width="30" height="40" fill="#FFCCBC" rx="5"/>
      <circle cx="200" cy="180" r="55" fill="#FFCCBC"/>
      <path d="M145,160 Q145,120 200,115 Q255,120 255,160 Q260,190 200,200 Q140,190 145,160" fill="#4E342E"/>
      <ellipse cx="175" cy="175" rx="8" ry="12" fill="white"/>
      <ellipse cx="225" cy="175" rx="8" ry="12" fill="white"/>
      <circle cx="175" cy="178" r="5" fill="#3E2723"/>
      <circle cx="225" cy="178" r="5" fill="#3E2723"/>
      <circle cx="176" cy="176" r="2" fill="white"/>
      <circle cx="226" cy="176" r="2" fill="white"/>
      <path d="M165,160 Q175,155 185,158" stroke="#3E2723" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <path d="M215,158 Q225,155 235,160" stroke="#3E2723" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <path d="M200,185 L195,205 L205,205 Z" fill="#FFAB91"/>
      <path d="M185,215 Q200,225 215,215" stroke="#D84315" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <rect x="110" y="280" width="30" height="140" fill="#FFCCBC" rx="15"/>
      <rect x="260" y="280" width="30" height="140" fill="#FFCCBC" rx="15"/>
      <circle cx="125" cy="420" r="18" fill="#FFCCBC"/>
      <circle cx="275" cy="420" r="18" fill="#FFCCBC"/>
      <rect x="165" y="410" width="30" height="150" fill="#1976D2" rx="10"/>
      <rect x="205" y="410" width="30" height="150" fill="#1976D2" rx="10"/>
      <ellipse cx="180" cy="570" rx="25" ry="15" fill="#424242"/>
      <ellipse cx="220" cy="570" rx="25" ry="15" fill="#424242"/>
      <circle cx="200" cy="300" r="4" fill="#1565C0"/>
      <circle cx="200" cy="330" r="4" fill="#1565C0"/>
      <circle cx="200" cy="360" r="4" fill="#1565C0"/>
    </svg>
  );
};

export default HumanModel;